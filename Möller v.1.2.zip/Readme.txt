M�ller - A Music Font for German Organ Tablature
Version 1.2 | 4/21/2017

PACKAGE CONTENTS
-----------------
- M�ller.otf
- M�ller User Manual.pdf
- M�ller Tablature Template.docx
- Bruhns Example.docx
- Readme.txt (this file)


INSTALLATION
------------
Install M�ller.otf before attempting to use the other files. On both Windows and Mac, this can be done by opening the font file and clicking 'Install' within the preview window that opens.